// sorting strings using qsort
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
int compare( const void *param1, const void *param2 )
{
   /* Compare param1 and param2 */
   return _stricmp( * ( char** ) param1, * ( char** ) param2 );
}
int main() {
   char* strArray[4] = {"Horse", "Elephant", "Donkey", "Camel"};
   /* _CRTIMP void   __cdecl qsort(void *,
                                   size_t,
                                   size_t,
                                   int (__cdecl *)(const void *, const void *));
   The last parameter is a function pointer
   */
   qsort( (void *)strArray, (size_t)4, sizeof( char * ), compare );
   /* print sorted array: */
   for( int i = 0; i < 4; ++i )
      printf( "%s\n", strArray[i] );
}

