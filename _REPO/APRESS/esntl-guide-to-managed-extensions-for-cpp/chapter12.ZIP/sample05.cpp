// airflow control program
#using <mscorlib.dll>
using namespace System;
#include <time.h>
#include <stdlib.h>

// delegate declaration
__delegate  void ControlAirFlow(int flowLevel);

__gc class CeilingFan {
  public:
    void TurnOff() { Console::WriteLine("CeilingFan::TurnOff"); }
    void Rotate(int speedLevel) {
        if (speedLevel == 0) { TurnOff(); }
        else {
            Console::Write("CeilingFan::Rotate at speed level ");
            Console::WriteLine(speedLevel);
        }
    }
};

__gc class AirConditioner {
  public:
    void TurnOff() { Console::WriteLine("AirConditioner::TurnOff"); }
    void BlowColdAir(int flowLevel) {
        if (flowLevel == 0) { TurnOff(); }
        else {
            Console::Write("AirConditioner::BlowColdAir at level ");
            Console::WriteLine(flowLevel);
        }
    }
};

void AirFlowController (ControlAirFlow* pCoolD) {
   enum Temperature {normal = 0, warm, hot};
   // generate random weather conditions
   srand( (unsigned)time( NULL ) );
   Temperature currentCondition = (Temperature) (rand()%3);

   switch (currentCondition) {
     case normal:   Console::WriteLine("Normal weather, air control not needed");
                    break;
     case warm:     Console::WriteLine("Warm weather");
                    break;
     case hot:      Console::WriteLine("Hot weather");
                    break;
   }
   pCoolD->Invoke(currentCondition);
}
int main() {
    // create an instance of AirConditioner
    AirConditioner *cooler = new AirConditioner();
    // create a single delegate with a  member function
    ControlAirFlow *pCoolD = new ControlAirFlow(cooler, &AirConditioner::BlowColdAir);

    // create an instance of CeilingFan
    CeilingFan *fan = new CeilingFan();
    // create a single delegate with a  member function
    ControlAirFlow *pFanD = new ControlAirFlow(fan, &CeilingFan::Rotate);

    // combine the two delegates to create a multicast delegate
    pFanD += pCoolD;

    // call the function that invokes the delegate
    AirFlowController (pFanD);
}

