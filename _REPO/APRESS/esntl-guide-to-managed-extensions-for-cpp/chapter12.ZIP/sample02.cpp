// air cooling program
#include <time.h>
#include <stdlib.h>
#using <mscorlib.dll>
using namespace System;

// delegate declaration
__delegate  void ControlAirFlow(int flowLevel);

__gc class AirConditioner {
  public:
    void TurnOff() { Console::WriteLine("AirConditioner::TurnOff"); }
    void BlowColdAir(int flowLevel) {
        if (flowLevel == 0) { TurnOff(); }
        else {
            Console::Write("AirConditioner::BlowColdAir at level ");
            Console::WriteLine(flowLevel);
        }
    }
};
void AirFlowController(ControlAirFlow* pCoolD) {
   enum Temperature {normal = 0, warm, hot};
   // generate random weather conditions
   srand( (unsigned)time( NULL ) );
   Temperature currentCondition = (Temperature) (rand()%3);

   switch (currentCondition) {
    case normal:  Console::WriteLine("Normal weather, air control not needed");
                  break;
    case warm:    Console::WriteLine("Warm weather");
                  break;
    case hot:     Console::WriteLine("Hot weather");
           break;
   }
   pCoolD->Invoke(currentCondition);
}
int main() {
    // create an instance of AirConditioner
    AirConditioner *cooler = new AirConditioner ();
    // create a single delegate with a member function
    ControlAirFlow *pCoolD = new ControlAirFlow(cooler, & AirConditioner::BlowColdAir);
    // call the function that invokes the delegate
    AirFlowController (pCoolD);
}

