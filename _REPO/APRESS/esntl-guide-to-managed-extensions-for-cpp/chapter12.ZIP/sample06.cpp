#using <mscorlib.dll>
using namespace System;

// DllImport is defined in System::Runtime::InteropServices
using namespace System::Runtime::InteropServices;

// wrapper class for the strlen function
__gc struct StringRoutines {
    [DllImport("msvcr70")]
        static int strlen( const char* );
};

// delegate declaration
__delegate int MyStrLen(const char *pText);

int main() {
    // create delegate
    MyStrLen *p = new MyStrLen(0, & StringRoutines::strlen);
   
    // invoke the delegated function
    int len = p->Invoke("Hello");
   
    Console::Write("Length of the string \"Hello\" is ");
    Console::WriteLine(len);
}

