#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;
#include <stdio.h>

class NativeAdder {
   public:
// method with a default argument
    int CumulativeSum(int delta, int currentTotal = 0) {
        return currentTotal + delta;
    }
};

public __gc class ManagedAdder {
    NativeAdder *pU;
    public:
        ManagedAdder () { pU = new NativeAdder (); }
        ~ ManagedAdder () { delete pU; }
        int CumulativeSum(int delta, int currentTotal) {
            return pU->CumulativeSum(delta, currentTotal);
        }
        int CumulativeSum(int delta) {
            return pU->CumulativeSum(delta, 0);
        }
};
int main() {
   ManagedAdder *m = new ManagedAdder ();
   int sum = m->CumulativeSum(10);
   sum = m->CumulativeSum(20, sum);
   Console::Write("10 + 20 = ");
   Console::WriteLine(sum);
}

