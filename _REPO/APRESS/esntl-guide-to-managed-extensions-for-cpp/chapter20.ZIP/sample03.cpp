#using <mscorlib.dll>
#include <stdio.h>
#include <stdarg.h>

class NativePrinter {
   public:
    void PrintNumbers(int count, ...) {
        printf("count is %d; numbers are ", count);
        va_list numbers;
        va_start(numbers, count);  // Initialize variable arguments
        for (int i = 0; i< count; i++) {
            printf("%d ", va_arg(numbers, int));
        }
        printf("\n");
        va_end(numbers);
    }
};
// Managed Wrapper
public __gc class ManagedPrinter {
    NativePrinter *pU;
    public:
        ManagedPrinter() { pU = new NativePrinter(); }
        ~ManagedPrinter() { delete pU; }
        void PrintNumbers(int count, int num1) {
            pU->PrintNumbers(count, num1);
        }
        void PrintNumbers(int count, int num1, int num2) {
            pU->PrintNumbers(count, num1, num2);
        }
        void PrintNumbers(int count, int num1, int num2, int num3) {
            pU->PrintNumbers(count, num1, num2, num3);
        }
};

int main() {
   ManagedPrinter *m = new ManagedPrinter();
   m->PrintNumbers(1, 10);
   m->PrintNumbers(2, 10, 20);
   m->PrintNumbers(3, 10, 20, 30); 
}

