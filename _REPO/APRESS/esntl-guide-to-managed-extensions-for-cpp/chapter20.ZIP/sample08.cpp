#using <mscorlib.dll>
using namespace System;
class Unmanaged {
   public:
    int m_number;
    Unmanaged(int i) : m_number(i){}
    Unmanaged* operator+(const Unmanaged *u) {
        m_number += u->m_number;
        return this;
    }
};
// wrapper class
public __gc class Managed {
    Unmanaged *pU;
    public:
        Managed(int i) { pU = new Unmanaged(i); }
        ~Managed() { delete pU; }
        __property int get_number() { return pU->m_number; }
        Unmanaged* GetPU() { return pU;}
        static Managed* op_Addition(Managed* m1, Managed* m2) {
            Unmanaged* u = m1->GetPU();
            u = *u + m2->GetPU();
            return m1;
        }
};
int main() {
   Managed *m1 = new Managed(20);
   Managed *m2 = new Managed(30);
   m1 = Managed::op_Addition(m1, m2);
   Console::WriteLine(m1->number);
}

