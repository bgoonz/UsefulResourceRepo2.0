#include <stdio.h>
#using <mscorlib.dll>
using namespace System;

class Unmanaged {
   int m_i;
   public:
    Unmanaged() : m_i(10){}
    Unmanaged(const Unmanaged& u) { *this = u; }
    void Print() { printf("%d\n", m_i); }
};

public __gc class Managed : public ICloneable{
    Unmanaged *pU;
    public:
        Managed() { pU = new Unmanaged(); }
        ~Managed() { delete pU; }
        Unmanaged* GetPU() { return pU; }
        void Print() { pU->Print(); }
        virtual Object* Clone() {  // copy constructor wrapper
            Managed* pM = new Managed();
            Unmanaged* pTmpU = pM->GetPU(); 
            *pTmpU = *pU; // calls copy constructor of Unmanaged
            return pM;
        }
};
int main() {
   Managed *m1 = new Managed();
   Managed *m2 = dynamic_cast<Managed *>(m1->Clone());
   m2->Print();
}

