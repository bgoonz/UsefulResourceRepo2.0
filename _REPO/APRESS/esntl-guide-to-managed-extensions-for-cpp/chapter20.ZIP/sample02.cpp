#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;
#include <stdio.h>

class Unmanaged {
   public:
    void PrintString(const char* str) {
       printf("%s\n", str);
    }
};
// wrapper class
public __gc class Managed {
    Unmanaged *pU;
    public:
        Managed() { pU = new Unmanaged(); }
        void PrintString(String *str) {
            char *pNativeStr = NULL;
            try {
                pNativeStr = static_cast<char*>
                             (Marshal::StringToHGlobalAnsi(str).ToPointer());
            }
            catch (Exception *e) {
                Console::WriteLine("String conversion to char* failed");
            }

            pU->PrintString(pNativeStr);

            Marshal::FreeHGlobal(pNativeStr);
        }
        ~Managed() { delete pU; }
};
int main() {
   Managed *m = new Managed();
   m->PrintString("An invitation from Managed World");
}

