#using <mscorlib.dll>
using namespace System;

class Unmanaged {
   int m_count;
   public:
    int m_total;
    Unmanaged() : m_count(0), m_total(0){}
    int GetCount() { return m_count; }
    void SetCount(int i) { m_count = i; }
};

public __gc class Managed {
    Unmanaged *pU;
    public:
        Managed() { pU = new Unmanaged(); }
        ~Managed() { delete pU; }
        __property int get_count() { return pU->GetCount(); }
        __property void set_count(int i) { pU->SetCount(i); }
        __property int get_total() { return pU->m_total; }
        __property void set_total(int n) { pU->m_total = n; }
};

int main() {
   Managed *m = new Managed();
   m->count = 20;
   m->total = m->count + 30;
   Console::WriteLine(m->count);
   Console::WriteLine(m->total);
}

