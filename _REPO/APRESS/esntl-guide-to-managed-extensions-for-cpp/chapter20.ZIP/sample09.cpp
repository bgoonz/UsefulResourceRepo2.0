#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;
#include <stdio.h>
typedef void (*FuncPtr)();
// native function that expects a function pointer as a parameter
void NativeFunc(FuncPtr f) {
  printf("Entered NativeFunc\n");
  f();
  printf("Exiting NativeFunc\n");
}

// delegate declaration
__delegate void CallBackFunc();
// managed class whose method is used as a delegated function
__gc struct ManagedClass {
  void ManagedFunc() {
   Console::WriteLine("ManagedClass::ManagedFunc()");
  }
};
// use the string copy function from kernel32 DLL.
// This basically returns the address of a delegated funcion
[DllImport("kernel32")]
extern "C" int lstrcpyn(Delegate* d1, int passMeZero, int passMeAnotherZero);
int main() {
  ManagedClass __gc* pM = new ManagedClass();
  // create a delegate
  CallBackFunc __gc* callBack = new CallBackFunc(pM, &ManagedClass::ManagedFunc);
  // pin the delegate so that it won't be garbage collected while the native
  // function is using it
  CallBackFunc __pin* pcallBack = callBack;

  // get the address of the code to execute the delegated function
  // Note: This is a workaround because this functionality is currently 
  // not directly supported in the .NET Framework
  int addr = lstrcpyn(callBack, 0, 0);
  // pass the address to the native function expecting a function pointer
  NativeFunc((FuncPtr)addr);
}

