#using <mscorlib.dll>
using namespace System;
class Native {
  int m_i;
 public:
  explicit Native(double f): m_i((int)f) {}; // conversion constructor
  Native(int i): m_i(i) {}; // conversion constructor
};
// wrapper class
public __gc class Managed {
  Native *pU;
  public:
  Managed(double f) { pU = new Native(f); }
  Managed(int i) { pU = new Native(i); }
  ~Managed() { delete pU; }

  static Managed* op_Explicit(double f) {
    return new Managed(f);
  }
  static Managed* op_Implicit(int i) {
    return new Managed(i);
  }
};
int main() {
  Managed *pM1 = new Managed(10);
  Managed *pM2 = Managed::op_Explicit(20.0);
}

