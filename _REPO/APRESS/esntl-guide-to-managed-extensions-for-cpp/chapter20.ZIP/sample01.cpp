#using <mscorlib.dll>
#include <stdio.h>
// unmanaged class
class Unmanaged {
    void PrivateFunc() { printf("Unmanaged::PrivateFunc\n"); }
   protected:
    void ProtectedFunc() { printf("Unmanaged::ProtectedFunc\n"); }
   public:
    void HelperFunc() { printf("Unmanaged::HelperFunc\n"); }
    void PublicFunc() {
       HelperFunc();
       printf("Unmanaged::PublicFunc\n");
    }
};
// Wrapper class
public __gc class Managed {
    Unmanaged *pU;
    public:
        Managed() { pU = new Unmanaged(); }
        ~Managed() { delete pU; }
        void PublicFunc() { pU->PublicFunc();}
};

int main() {
   Managed *m = new Managed();
   m->PublicFunc();
  }

