#using <mscorlib.dll>
using namespace System;
int main()
{
    // Declare and allocate managed array of 10 integers
    int MyArray __gc[] = new int __gc[10];
    // Try to access 21st element
    Console::WriteLine( MyArray[20] );
}

