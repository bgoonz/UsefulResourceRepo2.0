#using <mscorlib.dll>
using namespace System;
int main()
{
    Int32 arr[] = new Int32[5];
    for( int i=0; i<5; i++ )
    {
        arr[i] = i*10;
    }
    for( int i=0; i<5; i++ )
    {
        Console::WriteLine( arr[i] );
    }
}

