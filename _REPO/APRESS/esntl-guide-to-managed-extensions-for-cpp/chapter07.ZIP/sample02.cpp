#using <mscorlib.dll>
using namespace System;
int main()
{
    Array *pArr = Array::CreateInstance (__typeof(Int32), 5);
    for( int i=0; i<5; i++ )
    {
        pArr->SetValue( __box(i*10), i );
    }
    for( int i=0; i<5; i++ )
    {
        Console::WriteLine( pArr->GetValue( i ) );
    }
}

