#using <mscorlib.dll>
using namespace System;

__value class X : public IComparable
{
    int data_;
public:
    X(int i) { data_=i; }
    void Print() { Console::WriteLine( data_ ); }
    int CompareTo( Object* o )
    {
        X*pX = __try_cast<X*>(o);
        return pX->data_ < data_ ?
            1 : pX->data_ == data_ ?
            0 : -1;
    }
};
int main()
{
    // Fill up the array with random data
    X arr[] = { 4, 3, 5, 7, 0 };
    // Sort it
    Array::Sort(arr);
    for( int i = 0; i < arr->Length; i++ )
    {
        arr[i].Print();
    }
}

