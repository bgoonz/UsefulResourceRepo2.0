#using <mscorlib.dll> 
using namespace System;
public __gc class MyException : public ApplicationException {
    int num_;
    public:
        MyException(int i) : num_(i) {}
        int GetNum() {
            return num_;
        }
};
int main() {
    try {
        Console::WriteLine(S"Throwing a managed object of MyException");
        throw new MyException(10);
    }
    catch (MyException* pE) {
        Console::WriteLine(S"Caught a managed object of MyException");
        Console::Write(S"MyException object is created with ");
        Console::WriteLine(pE->GetNum());
        Console::WriteLine(pE->StackTrace);
    }
}

