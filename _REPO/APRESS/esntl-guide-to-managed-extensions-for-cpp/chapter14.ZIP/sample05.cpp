#using <mscorlib.dll> 
using namespace System;
public __value class V {
    public:
        void Func() {
            Console::WriteLine(S"V::Func()");
        }
};
int main() {
    try {
         V v;
         Console::WriteLine(S"throwing a value type object of V");
         throw __box(v); // boxed v is thrown
    }
    catch (__box V *pBoxedV) {
         Console::WriteLine(S"caught a value type object of V");
         pBoxedV->Func();
         V *pV = pBoxedV;  //  implicit unboxing
         pV->Func();
    }
    __finally {
          Console::WriteLine(S"in __finally block");
    }
}

