#include <stdio.h>
int main() {
  try {
    printf("throwing: \"I am an exception\"\n");
    throw "I am an exception";
  }
  catch (const char* str) {
    printf("caught: \"%s\"\n", str);
  }
  catch (int i) {
    printf("caught: %d\n", i);
  }
}

