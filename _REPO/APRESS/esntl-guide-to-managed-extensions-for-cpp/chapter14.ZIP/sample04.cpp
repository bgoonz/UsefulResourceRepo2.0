#using <mscorlib.dll> 
using namespace System;
public __gc class MyException : public ApplicationException {
      int count_;
      public:
              MyException(int i) : count_(i) {}
              int GetCount() {
                   return count_;
              }
};
int main() {
      try {
          Console::WriteLine(S"Throwing a managed object of MyException");
          throw new MyException(10);
      }
      catch (MyException* pE) {
          Console::WriteLine(S"Caught a managed object of MyException");
          Console::Write(S"MyException object is created with ");
          Console::WriteLine(pE->GetCount());
          Console::WriteLine(pE->ToString());
      }
      __finally {
          Console::WriteLine(L"in __finally block");
      }
}

