// compile with /EHsc /clr
#using <mscorlib.dll>
using namespace System;
public __gc class ExManaged : public ApplicationException {
public:
  void Func() {
    Console::WriteLine(L"ExManaged::Func()");
  }
};
class ExUnmanaged {
public:
  void Func() {
    Console::WriteLine(L"ExUnmanaged::Func()");
  }
};
int main() {
    try {
      try {
        Console::WriteLine(L"throwing a managed object of ExManaged");
        throw new ExManaged();
      }
      catch (ExManaged* pExManaged) {
        Console::WriteLine(L"caught a managed object of ExManaged");
        pExManaged->Func();
        Console::WriteLine(L"throwing an unmanaged object of ExUnmanaged");
        throw new ExUnmanaged();
      }
    }
    catch (ExUnmanaged* pExUnmanaged) {
       Console::WriteLine(L"caught an unmanaged object of ExUnmanaged");
       pExUnmanaged->Func();
    }
    __finally {
      Console::WriteLine(L"in __finally block");
    }
}

