#include <stdio.h>
#include <excpt.h>
int main() {
      __try{
         printf("in first try \n");
         int i = 1;
         int j = 0;
         i = i/j; // raises exception
      }
      __except( printf("in filter \n"), EXCEPTION_EXECUTE_HANDLER ) {
         printf("in except \n");
      }
      __try {
         printf("in second try \n");
         return 1;
      }
      __finally {
         printf("in finally \n"); // this is executed before exiting
      }
}

