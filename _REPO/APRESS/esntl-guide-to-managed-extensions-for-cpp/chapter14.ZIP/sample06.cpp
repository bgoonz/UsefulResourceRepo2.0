#using <mscorlib.dll>
using namespace System;
class E {
    public:
        void Func() {
            Console::WriteLine(L"E::Func()");
        }
};
int main() {
    try {
        Console::WriteLine(L"throwing an unmanaged object of E");
        throw new E();
    }
    catch (E* pE) {
        Console::WriteLine(L"caught an unmanaged object of E");
        pE->Func();
    }
    __finally {
        Console::WriteLine(L"in __finally block");
    }
}

