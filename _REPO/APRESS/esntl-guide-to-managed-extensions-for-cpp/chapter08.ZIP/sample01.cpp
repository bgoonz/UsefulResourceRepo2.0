#using <mscorlib.dll>
using namespace System;
void PrintTree( Object* pTree )
{
    Console::WriteLine(S"The tree is: {0}", pTree);
}
__value enum Tree{ linden, birch, maple };
int main()
{
    Tree tree = maple;
    PrintTree( S"oak" );
PrintTree( __box(tree) ); // note boxing
}

