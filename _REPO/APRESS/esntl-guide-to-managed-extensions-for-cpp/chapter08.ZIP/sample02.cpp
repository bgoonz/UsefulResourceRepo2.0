#using <mscorlib.dll>
using namespace System;
__value enum Tree{ linden, birch, maple };
int main()
{
    Array* theArray = Enum::GetValues(__typeof(Tree));
    for ( int i = 0; i < theArray->Length; i++ )
    {
        Console::WriteLine( theArray->GetValue(i) );
    }
}

