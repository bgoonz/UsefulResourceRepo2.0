#using <mscorlib.dll>
using namespace System;
__gc __interface IProfessor {
        String *Specialization();
};
__gc __interface IDoctor {
        String *Specialization();
};
__gc class CProfessor : public IProfessor{
    protected:
    String *m_Specialization;
      public:
      CProfessor(String *spl) : m_Specialization(spl) {}
      String* Specialization() { return m_Specialization;}
};
__gc class CProfessorDoctor : public CProfessor, public IDoctor {
    public:
    // no need to implement IDoctor::Specialization(),
    // the method CProfessor::Specialization() is reused.
    CProfessorDoctor(String *spl) : CProfessor(spl){}
};
int main() {
    CProfessorDoctor *pProfDoc = new CProfessorDoctor(S"Cardiology");
    IDoctor* pID = pProfDoc;
    Console::Write("Specialization is ");
    Console::WriteLine(pID->Specialization());
}

