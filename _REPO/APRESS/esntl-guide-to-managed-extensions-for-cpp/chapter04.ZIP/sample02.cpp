#using <mscorlib.dll>
__gc __interface Employee {
     __property int get_JobLevel();
     __property void set_JobLevel(int level);
};
__gc class Developer : public Employee {
     private:
        int m_level;
 public:
     __property int get_JobLevel() { return m_level;}
     __property void set_JobLevel(int level) { m_level = level;}
};
int main() {
   Employee *c = new Developer();
   c->JobLevel = 5; // set_JobLevel is called
   System::Console::WriteLine(c->JobLevel); // get_JobLevel is called
}

