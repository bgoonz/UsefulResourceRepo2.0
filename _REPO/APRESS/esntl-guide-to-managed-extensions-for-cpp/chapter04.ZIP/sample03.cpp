#using <mscorlib.dll>
using namespace System;
__gc __interface IEmployee {
    String* GetName();
};
__gc __interface IManager : IEmployee {
    int GetNumberOfReports();
};
__gc __interface IAdmin : IEmployee {
    int GetNumberOfEmpsSupported();
};
__gc class CSysAdmin : public IAdmin, public IManager {
    int m_Id;
    String* m_Name;
    int m_NumReports;
    int m_NumEmpsSupported;
public:
    CSysAdmin (int id) : m_Id(id) {
        // overly simplified
        if (id == 1) {
            m_Name = S"John";
            m_NumReports = 5;
            m_NumEmpsSupported = 0;
        }
    }
    String* GetName(){ return m_Name; }
    int GetNumberOfReports(){ return m_NumReports; }
    int GetNumberOfEmpsSupported() { return m_NumEmpsSupported;}
};
int main() {
    CSysAdmin *pCEmp = new CSysAdmin (1);
    Console::WriteLine(S"Name is {0}", pCEmp->GetName());
    Console::Write(S"Number of reports is ");
    Console::WriteLine(pCEmp->GetNumberOfReports());
}

