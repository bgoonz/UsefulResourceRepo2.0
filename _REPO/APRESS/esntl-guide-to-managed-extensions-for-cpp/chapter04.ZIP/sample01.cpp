#using <mscorlib.dll>
using namespace System;
__gc __interface IEmployeeFinances {
  void SetSalary(double salary);
  double GetSalary();
};
__gc __interface IEmployeeDetails {
  String* GetName();
  String* GetAddress();
};
__gc class CEmployee : public IEmployeeFinances, public IEmployeeDetails {
  int m_Id;
  double m_Salary;
  String* m_Name;
  String* m_Address;
public:
  CEmployee(int id) : m_Id(id) {
    // overly simplified
    if (id == 1) {
      m_Salary = 50000;
      m_Name = S"John";
      m_Address = S"1 Broadway St, NY, NY";
    }
  };
  void SetSalary(double salary) { m_Salary = salary; }
  double GetSalary() { return m_Salary; }
  String* GetName() { return m_Name; }
  String* GetAddress() { return m_Address; }
};
int main() {
  CEmployee* cEmp = new CEmployee(1);

  IEmployeeFinances *iEmpF = cEmp;
  iEmpF->SetSalary(100000);
  Console::Write(S"Salary is : ");
  Console::WriteLine(iEmpF->GetSalary());

  IEmployeeDetails *iEmpD = cEmp;
  Console::WriteLine(S"Name is : {0}", iEmpD->GetName());
  Console::WriteLine(S"Address is : {0}", iEmpD->GetAddress());
}

