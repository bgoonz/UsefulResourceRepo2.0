// EventReceiver.cpp
// Compile with /clr
#using <mscorlib.dll>
using namespace System;
#using "eventSource.dll"
[event_receiver(managed)] // optional
__gc class Customer {
   public:
      void ReadNews(String* news){
        Console::WriteLine(news);
      }
      void SubscribeToNews(CyberNews* publisher) {
          publisher->flashNews += new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
      void UnsubscribeToNews(CyberNews* publisher) {
          publisher->flashNews -= new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
};
int main() {
    CyberNews* pSource =  CyberNewsMarketing::GetNewsService();
    Customer* pCustomer = new Customer();
    pCustomer->SubscribeToNews(pSource);
    pSource->NewsHappened(L"Great News");
    pCustomer->UnsubscribeToNews(pSource);
}

