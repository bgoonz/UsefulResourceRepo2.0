#using <mscorlib.dll>
using namespace System;
// declare the delegate
public __delegate void FlashNewsDelegate(String* news);

[event_source(managed)] // optional
public __gc class CyberNews {
   public:
      // declare event
      __event FlashNewsDelegate *flashNews;

      // Fire the event
      void NewsHappened(String* news) {
        __raise flashNews(news); // use of __raise is optional
      }
};
[event_receiver(managed)] // optional
__gc class Customer {
   public:
      // event handler
        void ReadNews(String* news){
        Console::WriteLine(news);
      }
      // register with the event
      void SubscribeToNews(CyberNews* publisher) {
        publisher->flashNews += new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
      // unregister with the event
      void UnsubscribeToNews(CyberNews* publisher) {
        publisher->flashNews -= new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
};
int main() {
    CyberNews* pSource =  new CyberNews();
    Customer* pCustomer = new Customer();
    // register with the event
    pCustomer->SubscribeToNews(pSource);
    // Fire the event
    pSource->NewsHappened(L"Great News");
    // unregister with the event
    pCustomer->UnsubscribeToNews(pSource);
    // Fire the event
    pSource->NewsHappened(L"More Great News");
}

