#using <mscorlib.dll>
using namespace System;
public __delegate void FlashNewsDelegate(String* news);
public __gc class CyberNews {
   public:
      __event FlashNewsDelegate *flashNews;
};

