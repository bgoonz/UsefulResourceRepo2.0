// eventSource.cpp
// compile with /clr /LD
#using <mscorlib.dll>
using namespace System;
public __delegate void FlashNewsDelegate(String* news);

[event_source(managed)] // optional
public __gc class CyberNews {
   public:
      virtual __event FlashNewsDelegate *flashNews;
      // Fire the event
      virtual void NewsHappened(String* news) {
        flashNews(news);
      }
};
[event_source(managed)] // optional
public __gc class BigCyberNews : public CyberNews {
public:
    virtual __event FlashNewsDelegate *flashNews;
    String* GatherDetailedNews(String* news) {
        // gather detailed news
        return String::Concat(S"Details: ", news);
    }
    // Fire the event
    void NewsHappened(String* news) {
        news = GatherDetailedNews(news);
        flashNews(news);
    }
};
public __gc struct CyberNewsMarketing {
    static CyberNews *GetNewsService() {
        return new BigCyberNews();
    }
};

