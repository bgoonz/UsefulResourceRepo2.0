// EventSource.cpp
// Compile with /clr /LD
#using <mscorlib.dll>
using namespace System;
[event_source(managed)] // optional
public __gc class CyberNews {
   public:
      __event void FlashNews(String* news);

      // Fire the event
    void NewsHappened(String* news) {
       __raise FlashNews(news); // use of __raise is optional
    }
};

