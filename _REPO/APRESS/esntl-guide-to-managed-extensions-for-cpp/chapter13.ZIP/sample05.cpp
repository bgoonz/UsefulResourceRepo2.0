#using <mscorlib.dll>
using namespace System;
// declare the delegate
public __delegate void FlashNewsDelegate(String* news);
[event_source(managed)] // optional
public __gc class CyberNews {
   public:
    FlashNewsDelegate *newsDelegate;
    // Fire the event
    void NewsHappened(String* news) {
         if (newsDelegate != 0) {
            newsDelegate(news);
         }
    }
    __event void add_flashNews(::FlashNewsDelegate* eh) {
         newsDelegate = static_cast<::FlashNewsDelegate*>
                                  (System::Delegate::Combine(newsDelegate, eh));
    }
    __event void remove_flashNews(::FlashNewsDelegate* eh) {
        newsDelegate = static_cast<::FlashNewsDelegate*>
                                  (System::Delegate::Remove(newsDelegate, eh));
    }
    __event void raise_flashNews(System::String* i1) {
        if (newsDelegate != 0) {
            newsDelegate->Invoke(i1);
        }
    }
    CyberNews() {
        newsDelegate = 0;
    }
};

[event_receiver(managed)] // optional
__gc class Customer {
   public:
      // event handler
        void ReadNews(String* news){
        Console::WriteLine(news);
      }
      // register with the event
      void SubscribeToNews(CyberNews* publisher) {
        publisher->flashNews += new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
      // unregister with the event
      void UnsubscribeToNews(CyberNews* publisher) {
        publisher->flashNews -= new FlashNewsDelegate(this, &Customer::ReadNews);      
      }
};
int main() {
    CyberNews* pSource =  new CyberNews();
    Customer* pCustomer = new Customer();
    // register with the event
    pCustomer->SubscribeToNews(pSource);
    // Fire the event
    pSource->NewsHappened(L"Great News");
    // unregister with the event
    pCustomer->UnsubscribeToNews(pSource);
    // Fire the event
    pSource->NewsHappened(L"More Great News");
}

