// EventReceiver.cpp
// Compile with /clr
#using <mscorlib.dll>
using namespace System;
#using "event_source.dll"
[event_receiver(managed)] // optional
__gc class Customer {
   public:
      void ReadNews(String* news){
       Console::WriteLine(news);
    }
    void SubscribeToNews(CyberNews* publisher) {
       __hook(&CyberNews::FlashNews, publisher, &Customer::ReadNews);
    }
    void UnsubscribeToNews(CyberNews* publisher) {
       __unhook(&CyberNews::FlashNews, publisher, &Customer::ReadNews);
    }
};
int main() {
    CyberNews* pSource = new CyberNews();
    Customer* pCustomer = new Customer();
    pCustomer->SubscribeToNews(pSource);
    pSource->NewsHappened(L"Great News");
    pCustomer->UnsubscribeToNews(pSource);
}

