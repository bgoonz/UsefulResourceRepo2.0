#using <mscorlib.dll>
GetGeoCoordinates(int x,int y,double*lat,double*lon );
__gc class GeoPoint
{
    int x_;
    int y_;
    double lat_;
    double lon_;
public:
    void SetGeoCoordinates();
};
void GeoPoint::SetGeoCoordinates()
{
    GetGeoCoordinates(x_,y_,&lat_,&lon_);//error!
}
