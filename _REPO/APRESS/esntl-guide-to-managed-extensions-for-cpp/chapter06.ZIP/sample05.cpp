#using <mscorlib.dll>
__gc class ZipCode
{
int zipCode_;
public:
    ZipCode(int zipCode ):zipCode_(zipCode){};
};
void PassByRef(const ZipCode&);
int main()
{
    ZipCode&beverly_hills =*new ZipCode(90210 );
    PassByRef(beverly_hills );
}
