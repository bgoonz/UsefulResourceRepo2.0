#using <mscorlib.dll>
__gc class ZipCode
{
int zipCode_;
public:
    ZipCode(int zipCode ):zipCode_(zipCode){};
};
void PassByRef(const ZipCode&);
int main()
{
    PassByRef(90210 );//error
}
