#using <mscorlib.dll>
using namespace System;
__gc class MyClass{};
int main()
{
    Object* o = new MyClass;
    try
    {
        String* s = __try_cast<String*>(o);
    }
    catch( InvalidCastException* )
    {
        Console::WriteLine( "Conversion failed" );
    }
}

