#using <mscorlib.dll>
__gc struct G
{
    int data;
};
void PassByRef(int&);
int main()
{
    G*pG =new G;
    PassByRef(pG->data );//error!
}
