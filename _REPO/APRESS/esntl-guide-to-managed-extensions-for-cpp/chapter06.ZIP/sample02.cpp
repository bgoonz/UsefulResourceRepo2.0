#using <mscorlib.dll>
using namespace System;
__gc struct G
{
    Int32*pInt;//error!
};
