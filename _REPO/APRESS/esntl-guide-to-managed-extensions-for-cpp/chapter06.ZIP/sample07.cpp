#using <mscorlib.dll>
using namespace System;
int main()
{
    Object*o =S"hello";
    String*s =(String*)o;//warning!
}
