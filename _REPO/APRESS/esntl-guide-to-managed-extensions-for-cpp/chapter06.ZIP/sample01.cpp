#using <mscorlib.dll>
__gc struct G
{
    int data;
};
int main()
{
    G*pG =new G;
    int*p =&pG->data;//error!&pG->data is a gc pointer
}
