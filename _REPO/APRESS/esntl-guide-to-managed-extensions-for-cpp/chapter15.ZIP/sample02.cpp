#using <mscorlib.dll>
class Widget {
    char* name;
public:
    // ...
    const char* GetName() const { 
       return name; 
    }
};
__gc class Managed_Widget {
    Widget widget;
public:
    const char* GetName() {
         return widget.GetName();  // error !
    }
};

