#using <mscorlib.dll>
using namespace System;
#include <stdio.h>
void ManagedFunction() {
      printf("Hello from ManagedFunction\n"); 
}
#pragma unmanaged
void UnManagedFunction() { 
      printf("Hello from UnManagedFunction\n"); 
      ManagedFunction();
}
#pragma managed
int main() {
      UnManagedFunction();
}

