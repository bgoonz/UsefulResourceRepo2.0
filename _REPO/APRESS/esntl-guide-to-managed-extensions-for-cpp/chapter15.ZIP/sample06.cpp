#using <mscorlib.dll>
struct Gadget {
      System::String *name_; // error!
};

