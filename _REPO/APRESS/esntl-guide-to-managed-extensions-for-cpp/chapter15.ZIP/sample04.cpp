#using <mscorlib.dll>
using namespace System::Runtime::InteropServices;
[StructLayoutAttribute(Sequential)]
__value struct Point {
  int x;
  int y;
};
class NativeGraphics {
  Point pArray __nogc [2]; // okay
  Point p; // okay
};

