#include <stdio.h>
#include <time.h>
#using <mscorlib.dll>

int main() {
      clock_t t = clock();

      const int size = 100;
      int arr __gc[] = new int __gc[size];

      for( int iter=0; iter<100000; iter++ ) {
               for( int i=0; i<size; i++ ) {
                       arr[i] = size - i;
               }
               System::Array::Sort( arr );
      }

       printf("elapsed time: %2.2f sec\n", (clock()-t)/(double)CLOCKS_PER_SEC);
}

