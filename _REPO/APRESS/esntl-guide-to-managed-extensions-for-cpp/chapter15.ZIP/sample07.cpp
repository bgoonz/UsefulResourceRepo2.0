#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int compare( const void* px, const void* py ) {
      int x = *(int*)px;
      int y = *(int*)py;
      return x < y ? -1 : x > y ?  1 : 0;
}
int main() {
      clock_t t = clock();

      const int size = 100;
      int arr[size];
      for( int iter=0; iter<100000; iter++ ) {
            for( int i=0; i<size; i++ ) {
                  arr[i] = size - i;
            }
            qsort( (void *)arr, size, sizeof(int), compare );
      }
      printf("elapsed time: %2.2f sec\n", (clock()-t)/(double)CLOCKS_PER_SEC);
}

