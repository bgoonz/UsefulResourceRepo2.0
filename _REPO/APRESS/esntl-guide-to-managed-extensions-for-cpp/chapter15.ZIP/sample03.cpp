#using <mscorlib.dll>
#include <string>
class Widget {
      std::string name;
public:
      const std::string& GetName() const { 
         return name; 
      }
};
__gc class Managed_Widget {
      Widget *pWidget;
public:
      Managed_Widget() { 
         pWidget = new Widget; 
      }
      const std::string& GetName() { 
         return pWidget->GetName(); 
      }
      ~Managed_Widget() { 
         delete pWidget; 
      }
};

