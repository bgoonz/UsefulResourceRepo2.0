#using <mscorlib.dll>
#include <string>
class Widget {
      int length_;
public:
      int GetLength() const { 
         return length_; 
      }
};
__gc class Managed_Widget {
      Widget widget_;
public:
      __property int get_Length() {
        Widget __pin* pWidget = &widget_; // pinning the object
        return pWidget->GetLength(); // now we can call the member-function
      }
};

