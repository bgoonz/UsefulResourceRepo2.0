#include <stdio.h>
void PrintNumber();
int main() {
      PrintNumber(2001); // watch out!
}
void PrintNumber(int number) {
      printf( "number=%d\n", number );
}

