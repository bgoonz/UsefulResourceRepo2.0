#using <mscorlib.dll>
using namespace System;
#include <windows.h>

