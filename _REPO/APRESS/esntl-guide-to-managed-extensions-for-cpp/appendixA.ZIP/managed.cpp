// file: managed.cpp
extern void Func();
int main() {
   Func();
}

