//file:sample_part1.cpp
#using <mscorlib.dll>
using namespace System;
void Func(){ Console::WriteLine(S"sample_part1.cpp:Func()"); }
