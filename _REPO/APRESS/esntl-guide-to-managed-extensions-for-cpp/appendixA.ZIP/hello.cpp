// file: hello.cpp
#using <mscorlib.dll>
using namespace System;
int main() {
  Console::WriteLine(S"Hello from Managed World!");
}

