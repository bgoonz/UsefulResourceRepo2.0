//file:sample_part2.cpp
extern void Func();
int main(){
    Func();
}
