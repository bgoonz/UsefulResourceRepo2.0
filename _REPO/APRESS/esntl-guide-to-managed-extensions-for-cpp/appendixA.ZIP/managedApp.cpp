// file: managedApp.cpp
#using <mscorlib.dll>
#using "automobile.dll"
int main() {
  Automobile *pAuto = new Automobile();
  pAuto->PrintName();
}

