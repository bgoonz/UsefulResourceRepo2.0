// file: native.cpp
extern "C" int printf(...);
void Func() {
   printf("native function Func\n");
}

