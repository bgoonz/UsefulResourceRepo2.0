#using <mscorlib.dll>
using namespace System;

public __gc struct Automobile {
 /* declarations */
 static void PrintName() {
   Console::WriteLine(S"Automobile");
 }
};

