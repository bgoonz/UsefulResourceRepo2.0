#using <mscorlib.dll>
__abstract __gc class Base {};
__gc class Derived: public Base {};
int main() {
   Base *b = new Base(); // compiler reports error here
   Derived *d = new Derived(); // okay
}

