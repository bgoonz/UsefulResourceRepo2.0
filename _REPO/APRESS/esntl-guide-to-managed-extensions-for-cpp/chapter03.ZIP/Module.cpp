// file: Module.cpp
#using <mscorlib.dll>
private __gc class PrivateType{};
public __gc class PublicType1 {
  private:
    void PrivateFunc() {
       PrivateType* p;
       // ...
    }
};

