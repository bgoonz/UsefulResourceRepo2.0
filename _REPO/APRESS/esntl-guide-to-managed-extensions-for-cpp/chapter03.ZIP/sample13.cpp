#using <mscorlib.dll>
using namespace System;

public __gc class Outer {
  public:
      __gc class Inner {
           public:
             void InnerFunc() {
                 Console::WriteLine(L"Outer::Inner::InnerFunc()");
             }
      };
      void OuterFunc() {
           Console::WriteLine(L"Outer::OuterFunc()");
      }
};

int main() {
   Outer *o = new Outer();
   Outer::Inner *i = new Outer::Inner();
   o->OuterFunc();
   i->InnerFunc();
}

