#using <mscorlib.dll>
using namespace System;

__gc class Base {};
__gc class Derived : public Base{};
int main() {
    Base* pB = new Base();
    Base* pBD = new Derived();
    Object* pObj = pBD;

    Console::WriteLine("Type of pB object is {0}", pB->GetType());
    Console::WriteLine("Type of pBD object is {0}", pBD->GetType());
    Console::WriteLine("Type of pObj object is {0}", pObj->GetType());
}

