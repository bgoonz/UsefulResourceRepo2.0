#using <mscorlib.dll>
using namespace System;
__nogc class NoGCclass {
public:
   void Hello() { Console::WriteLine(S"Hello, from NoGCclass!"); }
};
__gc class GCclass {
public:
   void Hello() { Console::WriteLine(S"Hello, from GCclass!"); }
};
int main() {
    NoGCclass *pNoGC = new NoGCclass(); // creates an object on the C++ heap
    pNoGC->Hello();
    delete pNoGC; // needed because unmanaged objects are not garbage collected

    GCclass *pGC = new GCclass(); // creates an object on the GC heap
    pGC->Hello();
    // delete not needed because the garbage collector reclaims the memory
}

