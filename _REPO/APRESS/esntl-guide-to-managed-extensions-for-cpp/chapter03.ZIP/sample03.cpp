#using <mscorlib.dll>
    __gc class Object {
      public:
        Object();
        bool Equals(Object*);
        virtual int GetHashCode();
        System::Type* GetType();
        virtual System::String* ToString();

        static bool Equals(Object*, Object*);
        static bool ReferenceEquals(Object*, Object*);
      protected:
        void Finalize(); // C3840
        Object* MemberwiseClone();
    };

