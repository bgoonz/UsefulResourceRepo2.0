#using <mscorlib.dll>
using namespace System;
public __gc class Outer {
  private:
      int privateI;
  public:
      __gc class Inner {
           public:
             void InnerFunc(Outer *o) {
                   o->privateI = 10; // okay
                 Console::WriteLine(L"Outer::Inner::InnerFunc()");
             }
      };
      void OuterFunc() {
           Console::WriteLine(L"Outer::OuterFunc()");
      }
};

