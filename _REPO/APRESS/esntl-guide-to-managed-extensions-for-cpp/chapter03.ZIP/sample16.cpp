#using <mscorlib.dll>
__sealed __gc class NotABase {
   public:
         virtual void Func(){}
};
#pragma message("expected:")
#pragma message("sample16.cpp(10) : error C3246: 'Derived' : cannot inherit from 'NotABase' as it has been declared as '__sealed'")
#pragma message("         sample16.cpp(2) : see declaration of 'NotABase'")
#pragma message("result:")
__gc class Derived: public NotABase { // compiler reports error here
};


