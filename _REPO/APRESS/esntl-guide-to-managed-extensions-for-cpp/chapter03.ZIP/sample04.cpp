#using <mscorlib.dll>
using namespace System;
int main() {
   String* str1 = S"Hello";
   String* str2 = S"World";
   if (str1->Equals(str2)) {
     Console::WriteLine("strings {0} and {1} are the same", str1, str2);
   }
   else {
     Console::WriteLine("strings {0} and {1} are different", str1, str2);
   }
   String* str3 = S"Hello";
   if (str1->Equals(str3)) {
     Console::WriteLine("strings {0} and {1} are the same", str1, str3);
   }
   else {
     Console::WriteLine("strings {0} and {1} are different", str1, str3);
   }
}

