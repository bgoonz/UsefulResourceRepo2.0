#using <mscorlib.dll>
public __gc class PublicC {
  public protected:
    int publicProtectedMember; 
  protected private:
    int protectedPrivateMember;
};
private __gc class PrivateC {
  public protected:
    int publicProtectedMember; 
  protected private:
    int protectedPrivateMember;
};

