#using <mscorlib.dll>
using namespace System;
using namespace System::Text;

int main() {
  String* hello = S"Hello ";
  String* world = S"Managed World!";

  // Work  with StringBuilder
  StringBuilder* strBldr = new StringBuilder(hello);
  StringBuilder* strBldrOld = strBldr;
  strBldr = strBldr->Append(world); // append a string
  Console::WriteLine(strBldr->ToString());
  if (strBldr->Equals(strBldrOld)) { // compare new and old pointers
    Console::WriteLine("New and old StringBuilder instances are the same");
  }
  else {
    Console::WriteLine("New and old StringBuilder instances are different");
  }

  // Work with String
  String* str = hello;
  String* strOld = str; // save old pointer
  str = String::Concat(hello, world); // concatenate two strings
  Console::WriteLine(str);

  if (str->Equals(strOld)) { // compare new and old pointers
    Console::WriteLine("New and old String instances are the same");
  }
  else {
    Console::WriteLine("New and old String instances are different");
  }
}

