#using <mscorlib.dll>
using namespace System;
void main() {
   Type *t = __typeof(System::String);
   Console::WriteLine(t->ToString());
}

