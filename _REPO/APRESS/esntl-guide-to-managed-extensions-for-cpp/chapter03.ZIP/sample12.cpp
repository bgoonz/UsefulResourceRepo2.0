#using <mscorlib.dll>
using namespace System;
__gc class C {
private:
   static int m_staticI;
   static int m_staticJ;
public:
   static C() { m_staticI = 10; }
   int GetStaticI() { return m_staticI; }
   int GetStaticJ() { return m_staticJ; }
};
int main() {
   C *c = new C();
   Console::WriteLine(c->GetStaticI());
   Console::WriteLine(c->GetStaticJ());
};

