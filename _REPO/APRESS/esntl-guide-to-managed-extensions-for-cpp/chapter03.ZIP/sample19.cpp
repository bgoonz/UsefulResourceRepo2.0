#using <mscorlib.dll>
using System::String;
int main() {
   String *str1 = "string";
   String *str2 = L"wide string";
   String *str3 = "string";
};

