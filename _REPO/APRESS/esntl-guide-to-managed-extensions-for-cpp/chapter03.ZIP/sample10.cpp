#using <mscorlib.dll>
__gc class CBase {
   public:
      void CbaseFunc(){};
};
__gc __interface IFace1 {
     void IFace1Func();
};
__gc __interface IFace2 {
    void IFace2Func();
};
__gc class Derived : public CBase, public IFace1, public IFace2 {
   public:
     void IFace1Func(){};
     void IFace2Func(){};
};

