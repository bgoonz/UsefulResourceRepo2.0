// file: MyAssembly.cpp
#using <mscorlib.dll>
#using "Module.dll"
public __gc class PublicType2 {
  private:
    void Func() {
       PrivateType* p; // okay
       // ...
    }
  public:
    void PublicFunc(){ /* ... */ }
};

