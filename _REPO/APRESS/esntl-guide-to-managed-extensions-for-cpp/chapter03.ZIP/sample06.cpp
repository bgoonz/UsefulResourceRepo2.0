#using <mscorlib.dll>
using namespace System;

int main() {
    Object* pObj = new Object();
    Console::WriteLine("ToString() returned :{0}", pObj->ToString());
}

