#using <mscorlib.dll>
void main() {
   System::String *str1 = S"common language runtime string";
   System::String *str2 = S"common language runtime string";
};

