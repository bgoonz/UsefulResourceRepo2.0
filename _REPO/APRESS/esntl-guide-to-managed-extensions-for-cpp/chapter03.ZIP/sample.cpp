// sample.cpp
#using <mscorlib.dll>
using namespace System;
__gc class ManagedCpp {
public: 
   void Hello() { Console::WriteLine(S"Hello, from gc class!"); }
};
int main() {
      ManagedCpp *pMCpp = new ManagedCpp();
      pMCpp->Hello();
}

