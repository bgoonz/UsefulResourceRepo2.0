#using <mscorlib.dll>
using namespace System;
__nogc struct Unmanaged {
  ~Unmanaged() { Console::WriteLine(S"Unmanaged::Destructor"); }
};
__gc struct Managed {
  ~Managed() { Console::WriteLine(S"Managed::Finalizer"); }
};
__gc struct Base {
  ~Base() { Console::WriteLine(S"Base::Finalizer"); }
};
__gc struct Derived : Base {
     Managed *m;
     Unmanaged *uM;
     Derived() {
        m = new Managed();
        uM = new Unmanaged();
     }
    ~Derived(){
       Console::WriteLine(S"Derived::Finalizer");
       delete uM;
    }
};
int main() {
  Base *pBase = new Derived();
  delete pBase;
  Console::WriteLine(S"Call to the delete operator returned");
}

