#using <mscorlib.dll>
using namespace System;
class UnmanagedBase {};
__gc class ManagedBase{};
class UnmanagedDerived : public ManagedBase {};  // error
__gc class ManagedDerived : public UnmanagedBase {};  // error

