#using <mscorlib.dll>
__gc class Base {
   public:
      __sealed virtual void Func() {}
};
__gc class Derived : public Base {
   public:
#pragma message("expected:")
#pragma message("sample17.cpp(12) : error C3248: 'Base::Func': function declared as '__sealed'; cannot be overridden by 'Derived::Func'")
#pragma message("        sample17.cpp(4) : see declaration of 'Base::Func'")
#pragma message("result:")
        void Func()  {} // compiler reports error here
};

