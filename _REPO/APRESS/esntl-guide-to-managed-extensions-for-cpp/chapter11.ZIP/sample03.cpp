#using<mscorlib.dll>
#include <assert.h>
using namespace System;
using namespace System::Reflection;

// Define custom attribute
[AttributeUsage(AttributeTargets::Class|AttributeTargets::Method, AllowMultiple = true, Inherited = true)]
public __gc class  DocumentationAttr {
public:
     DocumentationAttr(String *str) : m_DocStr(str){}
     __property String *get_DocStr() {
               return m_DocStr;
     }
private:
     String *m_DocStr;
};
// Attach custom attribute to a class
[DocumentationAttr("to be documented")]
public __gc
class AClass  {
  public:
   [DocumentationAttr("to be implemented")]
   [DocumentationAttr("to be documented")]
   virtual void VirtualFunc() {
      //...
   }
};

// Inheritable custom attributes get attached
public __gc
class BClass : public AClass {
  public:
   void VirtualFunc() {
      //...
   }
};
//Print the the contents of the custom attribute 'DocumentationAttr'
void PrintCustomAttrContents(Object* pT) {

   Object *pObjs __gc[] = 0;
   MemberInfo *mem;

   Type *typ = dynamic_cast<Type *>(pT);
   if (typ != 0) {
      // argument's type is Type *
      pObjs = Attribute::GetCustomAttributes(static_cast<Type *>(pT));
   }
   else {
      mem  = dynamic_cast<MemberInfo *>(pT);
      if (mem != 0) {
         // argument's type is MemberInfo *
         pObjs = Attribute::GetCustomAttributes(static_cast<MemberInfo *>(pT));
      }
      else {
         assert (!"Unknown parameter passed");
      }
   }

   //Access custom attributes for an Object via Reflection
   if (pObjs != 0) {
      for(int i=0; i < pObjs->Length; i++) {
         if(pObjs[i]->GetType()->Equals(__typeof(DocumentationAttr))) {
            if (typ != 0) {
               Console::Write(S"Class  '");
            }
            else {
               Console::Write(S"    Member function '");
            }
            Console::Write(pT->ToString());
            Console::Write(S"' is  ");
            Console::WriteLine(static_cast<DocumentationAttr*>(pObjs[i])->DocStr);
         }
      }
   }
}

int main() {
   Type* pT = __typeof(AClass);
   PrintCustomAttrContents(pT); 

   MemberInfo *m __gc[]  = __typeof(AClass)->GetMember("VirtualFunc");
   PrintCustomAttrContents(m[0]); 

   pT = __typeof(BClass);
   PrintCustomAttrContents(pT); 

   m = __typeof(BClass)->GetMember("VirtualFunc");
   PrintCustomAttrContents(m[0]); 
}

