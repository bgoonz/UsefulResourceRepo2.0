#using <mscorlib.dll>
#using "DocAttribute.dll" // from the previous sample
using namespace System;
// Attach custom attribute to a class
[DocumentationAttr("to be implemented")]
public __gc
class AClass  {
      //...
};
// Attach custom attribute to another class
[DocumentationAttr("to be documented")]
public __gc
class BClass  {
   public:
      void Func(){}
};
// Print the the contents of the custom attribute 'MyCustomAttr'
void PrintDocumentationAttrContents(Type* pT) {
   // Access custom attributes for an Object via CLR Reflection
   Object* pObjs __gc[] = Attribute::GetCustomAttributes(pT);

   for(int i=0; i < pObjs->Length; i++) {
      if(pObjs[i]->GetType()->Equals(__typeof(DocumentationAttr))) {
     
         Console::Write(pT->ToString());
         Console::Write(S" is  ");
         Console::WriteLine(static_cast<DocumentationAttr*>(pObjs[i])->DocStr);
      }
   }
}
int main() {
   Type* pT = __typeof(AClass);
   PrintDocumentationAttrContents(pT);
   pT = __typeof(BClass);
   PrintDocumentationAttrContents(pT);
}

