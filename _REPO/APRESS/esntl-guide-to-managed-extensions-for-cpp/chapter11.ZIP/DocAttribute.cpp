// filename: DocAttribute.cpp
#using<mscorlib.dll>
using namespace System;
// Define custom attribute
[AttributeUsage(AttributeTargets::Class)]
public __gc class  DocumentationAttr {
public:
     DocumentationAttr(String *str) : m_DocStr(str){}
     __property String *get_DocStr() {
               return m_DocStr;
     }
private:
     String *m_DocStr;
};

