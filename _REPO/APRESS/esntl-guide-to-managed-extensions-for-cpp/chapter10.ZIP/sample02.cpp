#using <mscorlib.dll>
using namespace System;
__value class Temperature
{
    short int temp_;
    static const int nFactor_ = 100;
public:
    Temperature(double temp) { temp_ = (short int)(temp *  nFactor_); }
    static double op_Implicit(Temperature t)
{ return (double)t.temp_ / (double)nFactor_; }
    static int op_Explicit(Temperature t) { return (int)(t.temp_ / nFactor_); }
};

void main()
{
    Temperature Seattle(42.5);
    Temperature Madrid(71.25);

    double dAverageTemp = (Madrid + Seattle)/2;        // implicit conversion
    int iAverageTemp = ((int)Madrid + (int)Seattle)/2; // explicit conversion

    Console::WriteLine(dAverageTemp);
    Console::WriteLine(iAverageTemp);
}

