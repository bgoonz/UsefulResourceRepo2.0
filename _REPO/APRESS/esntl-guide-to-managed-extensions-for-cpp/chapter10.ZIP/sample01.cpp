#using <mscorlib.dll>
using namespace System;
__value class Matrix
{
    // ...
public:
    Matrix(UInt32 widht, UInt32 height);
    static Matrix op_Addition(Matrix a, Matrix b);
    static Matrix op_Subtraction(Matrix a, Matrix b);

    static Matrix op_Addition(double a, Matrix b);
    static Matrix op_Subtraction(double a, Matrix b);
    static Matrix op_Addition(Matrix a, double b);
    static Matrix op_Subtraction(Matrix a, double b);

    static bool op_Equality(Matrix l, Matrix r);
};
void main()
{
    Matrix a(10,15);
    Matrix b(10,15);
    // ...
    Matrix c = (a - b) + 10;
    Matrix d = 10 + (a - b);
    if( c == d )
    {
        Console::WriteLine(S"All right");
    }
}

