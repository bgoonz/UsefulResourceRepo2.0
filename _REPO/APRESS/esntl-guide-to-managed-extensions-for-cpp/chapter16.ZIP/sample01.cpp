#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

[DllImport("msvcr70", CharSet=CharSet::Auto)]
extern "C" int wcslen( String* pText );

int main() {
     String* str = L"Hello World!";
     int length = wcslen(str);
     Console::Write(S"Length of the string \"Hello World!\" is ");
     Console::WriteLine(length);
}

