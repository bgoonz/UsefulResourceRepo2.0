#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

[DllImport("msvcr70", CharSet=CharSet::Auto)]
extern "C" double sin ([MarshalAs(UnmanagedType::R8)] double f); 
                                          // attribute is optional

int main() {
      double pi = 3.1415926535;
      double sinPiBy2 = sin(pi/2);
      Console::WriteLine(sinPiBy2);
}

