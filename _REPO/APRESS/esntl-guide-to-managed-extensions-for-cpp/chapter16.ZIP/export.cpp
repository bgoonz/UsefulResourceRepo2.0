// file: export.cpp
// compile with /LD
#include <windows.h>
extern "C" {
 __declspec(dllexport) 
 int AreYouDone(void (CALLBACK *callback)(const char* answer,
                                          const char* reason)) { 
       callback("Not Done", "Project is too big");
       return 0;
 }
}

