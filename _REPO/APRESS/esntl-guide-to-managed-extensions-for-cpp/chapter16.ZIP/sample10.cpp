#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

[ StructLayout( LayoutKind::Sequential, CharSet=CharSet::Ansi )]
public __value struct Person {
      String *first;
      String *last;
      Person( String *firstName, String *lastName ) {
            first = firstName;
            last = lastName;
      }
};

[ DllImport( "NativeSort.dll" )]
extern "C" int SortArrayOfStructs( [In, Out] Person personArray __gc[], int size );
int main() {
      Person persons __gc[]= { Person( S"John", S"Smith" ),
                               Person( S"Anthony", S"Marshal" ), 
                               Person( S"Sara",S"Justice" )
                             };
      Console::WriteLine( "Person array before sorting by last name:" );
      for( int i = 0; i < persons->Length; i++ )
         Console::WriteLine( "last = {0}, first = {1}", persons[i].last, 
                                                        persons[i].first );
      SortArrayOfStructs( persons, persons->Length );

      Console::WriteLine( "\nPerson array after sorting by last name:" );
      for( int i = 0; i < persons->Length; i++ )
         Console::WriteLine( "last = {0}, first = {1}", persons[i].last, 
                                                        persons[i].first );
}

