// file: NativeSort.cpp
#include <string.h>
struct Person {
    char* first;
    char* last;
};

extern "C" __declspec(dllexport) 
void SortArrayOfStructs( Person* pPersonArray, int size ) {
    for( int i = 0; i < size; i++ ) {
        for (int j = i+1; j < size; j++) {
           if (strcmp(pPersonArray[i].last, pPersonArray[j].last) > 0) {
              // exchange pPersonArray[i] and pPersonArray[j]
              char* last = pPersonArray[i].last;
              char* first = pPersonArray[i].first;

              pPersonArray[i].last = pPersonArray[j].last;
              pPersonArray[i].first = pPersonArray[j].first;

              pPersonArray[j].last = last;
              pPersonArray[j].first = first;
           }
       }
    }
}

