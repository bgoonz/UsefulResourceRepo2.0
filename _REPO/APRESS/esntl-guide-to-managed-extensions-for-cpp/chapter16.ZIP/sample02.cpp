#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;
[ DllImport( "NativeClass.dll",
             EntryPoint="?Func@ExportedClass@@QAEHH@Z",
             CallingConvention=CallingConvention::ThisCall )]
extern "C" int CallFunc( IntPtr ths, int i );

[ DllImport( "NativeClass.dll" )]
extern "C" void CreateExportedClassObj(IntPtr ths);

[ DllImport( "NativeClass.dll" )]
extern "C" void DeleteExportedClassObj( IntPtr obj );

int main() {
   IntPtr pExport;
   CreateExportedClassObj(pExport);

   int result = CallFunc( pExport, 100 );
   Console::WriteLine( "Func() returned {0}", __box(result) );

   DeleteExportedClassObj( pExport );
}

