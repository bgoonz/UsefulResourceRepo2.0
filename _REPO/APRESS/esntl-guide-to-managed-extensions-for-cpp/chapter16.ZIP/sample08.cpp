#using <mscorlib.dll>
using namespace System;
using namespace System::Text;
using namespace System::Runtime::InteropServices;

[DllImport("msvcr70", CharSet=CharSet::Ansi)]
extern "C" int strcat( StringBuilder* str1, String* str2 );

int main() {
     StringBuilder* str1 = new StringBuilder(S"Hello ");
     String* str2 = S"World!";
     Console::WriteLine(S"str1 : {0}", str1);
     Console::WriteLine(S"str2 : {0}", str2);
     strcat(str1, str2);
     Console::WriteLine(S"str1 after appending str2 : {0}", str1);
}

