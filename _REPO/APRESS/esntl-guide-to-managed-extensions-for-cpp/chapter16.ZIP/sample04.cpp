#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

__delegate bool CallBack (String* answer, String* reason);
__gc class Client {
  public:
    bool CallMeBack(String* answer, String* reason) {
        Console::WriteLine(S"Consultant says : {0}", answer);
        Console::WriteLine(S"Reason is : {0}", reason);
        return false;
    }
};

[DllImport("export", CharSet=CharSet::Ansi)]
extern "C" int AreYouDone( CallBack* call);

int main() {
     Client *c = new Client();
     CallBack *call = new CallBack(c, &Client::CallMeBack);
     AreYouDone(call);
     GC::KeepAlive(call);
}

