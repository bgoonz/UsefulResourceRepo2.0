#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;

[DllImport("msvcr70", CharSet=CharSet::Ansi)]
extern "C" int strlen( [MarshalAs(UnmanagedType::LPStr)] String* pText );

int main() {
     String* str = S"Hello World!";
     int length = strlen(str);
     Console::Write(S"Length of the string \"Hello World!\" is ");
     Console::WriteLine(length);
}

