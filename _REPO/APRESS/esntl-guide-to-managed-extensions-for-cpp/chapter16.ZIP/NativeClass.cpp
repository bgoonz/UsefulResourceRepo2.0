// file: NativeClass.cpp
#include <stdio.h>
class __declspec(dllexport) ExportedClass
{
public:
    int Func( int i ) { return i;}
};

extern "C" __declspec(dllexport) void CreateExportedClassObj(ExportedClass* obj) {
    obj = new  ExportedClass();
    printf("Object of ExportedClass Created\n");
}

extern "C" __declspec(dllexport) 
void DeleteExportedClassObj( ExportedClass* instance ) {
    delete instance;
    printf("Object of ExportedClass Destroyed");
}

