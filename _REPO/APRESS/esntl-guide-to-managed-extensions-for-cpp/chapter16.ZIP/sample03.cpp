#using <mscorlib.dll>
using namespace System;
using namespace System::Runtime::InteropServices;
public __gc struct StringLibrary {
    [DllImport("msvcr70", CharSet=CharSet::Auto)]
    static int wcslen( String* pText );
};
int main() {
     String* str = L"Hello World!";
     int length = StringLibrary::wcslen(str);
     Console::Write(S"Length of the string \"Hello World!\" is ");
     Console::WriteLine(length);
}

