#using <mscorlib.dll>
using namespace System;
__value struct RECT
{
    UInt32 left;
UInt32 right;
    UInt32 top;
UInt32 bottom;
    String* ToString() { return S"RECT"; }
};
int main()
{
    RECT rc = {0,0,100,100};
    Console::WriteLine (rc.ToString());    // OK!
}

