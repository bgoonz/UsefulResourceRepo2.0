#using <mscorlib.dll>
using namespace System;
__value struct V : public IComparable
{
    int data_;
    V(int i) { data_=i; }
    int CompareTo( Object* o )
    {
        V v = *__try_cast<V*>(o);
        return v.data_ < data_ ? 1 : v.data_ == data_ ? 0 : -1;
    }
};
int main()
{
    V arr[] = { 4, 3, 0, 1, 2, 5 };
    Array::Sort(arr);

    for( int i=0; i<arr->Length; i++ )
    {
        Console::WriteLine( arr[i].data_ );
    }
}

