#using <mscorlib.dll>
using namespace System;
__value struct POINT
{
    UInt32 x;
    UInt32 y;
};
int main()
{
    POINT a ={100,200};
    __box POINT*pbp =__box(a);
    pbp->x =300;//Note:implicit unboxing under the hood
    Console::WriteLine(a.x );
    Console::WriteLine(pbp->x );
}
