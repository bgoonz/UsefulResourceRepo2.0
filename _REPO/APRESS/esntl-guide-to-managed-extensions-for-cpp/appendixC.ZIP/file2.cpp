// filename: file2.cpp
#using <mscorlib.dll>
public __value struct V {
   int m_j;
};

