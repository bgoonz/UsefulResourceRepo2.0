#using <mscorlib.dll>
using namespace System;
using namespace System::Reflection;
using namespace System::Reflection::Emit;
// Build and save a dynamic assembly using Reflection Emit API.
void CreateDynamicAssembly(AppDomain *domain) {
  // set the assembly name
  AssemblyName *assemblyName = new AssemblyName();
  assemblyName->Name = S"DynAssembly";
  // define the assembly
  AssemblyBuilder *assemblyBuilder = 
      domain->DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess::Save);
  // define a module for the assembly
  ModuleBuilder *moduleBuilder = 
      assemblyBuilder->DefineDynamicModule(S"DynModule", S"DynModule.mod");
    // define a public type
    TypeBuilder *typeBuilder = 
                  moduleBuilder->DefineType(S"MyType", TypeAttributes::Public);
    // define a public method for the type
  MethodBuilder *methodBuilder = 
                    typeBuilder->DefineMethod(S"SayHello", 
                                              MethodAttributes::Public, 
                                              CallingConventions::Standard, 
                                              __typeof(void), 
                                              0);
    // add code for the body of the method
  ILGenerator *ilGenerator = methodBuilder->GetILGenerator();
  ilGenerator->EmitWriteLine(S"Hello, World!");
  ilGenerator->Emit(OpCodes->Ret);
  // create the type and get the assembly
  AssemblyBuilder* obj = 
      dynamic_cast<AssemblyBuilder*>(typeBuilder->CreateType()->Assembly);
  // save the assembly
  assemblyBuilder->Save(S"DynAssembly.dll");
}
int main() {
   AppDomain *currentDomain = AppDomain::CurrentDomain;
   CreateDynamicAssembly(currentDomain);
}

