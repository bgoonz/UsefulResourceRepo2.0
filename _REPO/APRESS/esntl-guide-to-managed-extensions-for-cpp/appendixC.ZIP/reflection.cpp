#using <mscorlib.dll>
using namespace System;
using namespace System::Reflection;
using namespace System::IO;

void ListAllTypesAndMembers(Assembly *a) {
    Console::WriteLine("Method: ListAllTypesWithMembers");
    Console::WriteLine("Types for {0}", a->FullName);
    Type *types __gc[] = a->GetTypes();
    for (int i = 0; i < types->Length; i++) {
        Console::WriteLine("   {0}", types[i]);
        MemberInfo *members __gc[] = types[i]->GetMembers();
        Console::WriteLine("      Members for {0}", types[i]->FullName);
        for (int j = 0; j < members->Length; j++) {
            Console::WriteLine("      {0}", members[j]);
        }
    }
    Console::WriteLine("\n");
}
int main() {
    Assembly *a = 0;
    try {
        Console::WriteLine("Type an assembly name without .dll");
        String* assemblyName = Console::ReadLine();
        a = Assembly::Load(assemblyName);
        ListAllTypesAndMembers(a);
    }
    catch(FileNotFoundException *e) {
        Console::WriteLine(e->Message);
    }
}

