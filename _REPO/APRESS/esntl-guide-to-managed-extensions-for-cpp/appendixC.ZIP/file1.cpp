// filename: file1.cpp
#using <mscorlib.dll>
public __gc class Managed {
   int m_i;
 public:
   __property int get_i() {
      return m_i;
   }
   __property void set_i(int val) {
      m_i = val;
   }
};

