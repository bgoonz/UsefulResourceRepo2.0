// filename: assem.cpp
#using <mscorlib.dll>
#using "file1.dll"
#using "file2.dll"
using namespace System;

int main() {
  Managed *m = new Managed();
  m->i = 10;
  Console::WriteLine(m->i);
  V v;
  v.m_j = 20;
  Console::WriteLine(v.m_j);
}

