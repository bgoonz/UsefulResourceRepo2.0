//filename:hello.cpp
#using <mscorlib.dll>
int main(){
    System::Console::WriteLine(S"Hello From Managed World!");
}
