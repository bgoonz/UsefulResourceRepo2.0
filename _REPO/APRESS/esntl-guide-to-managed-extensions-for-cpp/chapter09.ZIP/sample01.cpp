#using<mscorlib.dll>
using namespace System;
void main()
{
    // Print current directory
    Console::WriteLine( Environment::CurrentDirectory );
}

