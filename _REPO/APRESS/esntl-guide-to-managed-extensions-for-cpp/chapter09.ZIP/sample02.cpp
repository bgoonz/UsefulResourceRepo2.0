#using <mscorlib.dll>
using namespace System;
__gc class Student
{
    String*name_;
    String*address_;
    /*...*/
public:
    __property String*get_Address(){return address_;}
    __property void set_Address(String*address )
    {address_=address;}
    /*...*/
};
__gc class Database
{
    Student*students_[];
    int MapNameToId(String*name );
public:
    __property String*get_Address(int id )
    {
        return students_[id ]->Address;
    }
    __property String*get_Address(String*name )
    {
        int id =MapNameToId(name );
        return students_[id ]->Address;
    }
protected:
    __property void set_Address(int id,String *address )
    {
        students_[id ]->Address =address;
    }
    __property void set_Address(String*name,String *address )
    {
        int id =MapNameToId(name );
        students_[id ]->Address =address;
    }
};

Database*OpenDatabase();
int main()
{
    Database*pDatabase =OpenDatabase();
    String*address1 =pDatabase->Address ["John"];
    String*address2 =pDatabase->Address [89640 ];
}
