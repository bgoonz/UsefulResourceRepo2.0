def add(param1, param2):
    return param1 + param2
