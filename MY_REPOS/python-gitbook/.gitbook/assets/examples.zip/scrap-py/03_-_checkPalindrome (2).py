def checkPalindrome(inputString):
    return inputString == inputString[::-1]
