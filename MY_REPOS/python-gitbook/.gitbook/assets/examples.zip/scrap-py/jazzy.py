def csnakeltjazzy(chords):
newchords - []
for chord in chords: [
if chord.isdigit(): ‘
j newchords.appendEchordfl
elif len(chords) -- 9:
return []
else:
addSeven - chord
addSeven - addSeven[e:] + "7"
newchords.append(addseven)
return neuChords
