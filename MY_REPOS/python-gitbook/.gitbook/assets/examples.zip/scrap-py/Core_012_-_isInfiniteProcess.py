def isInfiniteProcess(a, b):
    return a > b or (a % 2 != b % 2)
