def reachNextLevel(experience, threshold, reward):
    return experience + reward >= threshold
