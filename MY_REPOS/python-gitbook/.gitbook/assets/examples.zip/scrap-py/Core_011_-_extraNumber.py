def extraNumber(a, b, c):
    if a == b:
        return c
    if a == c:
        return b
    return a
