def willYou(young, beautiful, loved):
    return (young and beautiful) != loved
