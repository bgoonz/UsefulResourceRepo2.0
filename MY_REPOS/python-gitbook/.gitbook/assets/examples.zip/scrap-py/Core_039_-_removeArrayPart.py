def removeArrayPart(inputArray, l, r):
    return inputArray[:l] + inputArray[r + 1 :]
