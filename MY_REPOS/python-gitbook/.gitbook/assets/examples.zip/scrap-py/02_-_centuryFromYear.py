def centuryFromYear(year):
    return ((year - 1) // 100) + 1
