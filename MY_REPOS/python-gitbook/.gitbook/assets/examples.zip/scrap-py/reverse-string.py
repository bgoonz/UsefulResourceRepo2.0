def csReverseString(chars):
    rev = chars[::-1]
    print(rev)
    return rev
