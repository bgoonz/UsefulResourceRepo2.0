def circleOfNumbers(n, firstNumber):
    return (firstNumber + (n // 2)) % n
