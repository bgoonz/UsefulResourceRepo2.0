def largestNumber(n):
    return int("9" * n)
