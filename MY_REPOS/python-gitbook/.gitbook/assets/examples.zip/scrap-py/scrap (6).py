languages = ["Java", "Python", "JavaScript"]
versions = [14, 3, 6]

result = zip(languages, versions)
print(list(result))
