def firstDigit(inputString):
    for char in inputString:
        if char.isdigit():
            return char
