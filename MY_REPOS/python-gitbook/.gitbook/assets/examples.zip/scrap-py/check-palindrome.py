def csCheckPalindrome(input_str):
    if input_str[::-1] == input_str:
        return True
    return False
