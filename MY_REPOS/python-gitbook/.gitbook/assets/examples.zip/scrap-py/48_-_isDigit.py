def isDigit(symbol):
    return symbol.isdigit()
