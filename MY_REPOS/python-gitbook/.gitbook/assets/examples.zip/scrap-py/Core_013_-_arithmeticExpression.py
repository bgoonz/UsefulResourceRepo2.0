def arithmeticExpression(a, b, c):
    return a + b == c or a - b == c or a * b == c or a / b == c
