def findEmailDomain(address):
    return address[address.rfind("@") + 1 :]
