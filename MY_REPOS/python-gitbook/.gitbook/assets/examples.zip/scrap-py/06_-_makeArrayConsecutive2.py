def makeArrayConsecutive2(statues):
    return max(statues) - min(statues) - len(statues) + 1
