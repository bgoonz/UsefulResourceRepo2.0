class Node:
    
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data
    
    def insert(self, data):
        # Checks if node exists
        if self.data:
            if data < 
