/*
Enter your query here.
*/
select city, state from station;