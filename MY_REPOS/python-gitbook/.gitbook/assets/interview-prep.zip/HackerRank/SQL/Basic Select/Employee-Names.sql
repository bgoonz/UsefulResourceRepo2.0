/*
Enter your query here.
*/
select name
from employee
order by name;