/*
Enter your query here.
*/
select distinct city from station where id % 2 = 0;