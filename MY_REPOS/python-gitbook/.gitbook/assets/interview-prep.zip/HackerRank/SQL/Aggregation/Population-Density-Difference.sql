select max(population) - min(population)
from city;