select sum(population)
from city
where district = 'california';