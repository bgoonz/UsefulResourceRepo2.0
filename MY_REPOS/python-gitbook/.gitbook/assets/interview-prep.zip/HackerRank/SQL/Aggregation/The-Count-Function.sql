select count(name)
from city
where population > 100000;