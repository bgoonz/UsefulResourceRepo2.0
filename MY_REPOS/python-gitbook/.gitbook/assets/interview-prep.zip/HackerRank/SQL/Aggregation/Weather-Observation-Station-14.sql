/*
Enter your query here.
*/
select round(max(lat_n), 4)
from station
where lat_n < 137.2345;