select round(avg(population), 0)
from city;