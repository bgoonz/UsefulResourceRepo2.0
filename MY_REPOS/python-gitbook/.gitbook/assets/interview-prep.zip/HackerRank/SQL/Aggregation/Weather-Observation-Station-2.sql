/*
Enter your query here.
*/
select 
    round(
        sum(lat_n),
        2
    ),
    round(
        sum(long_w),
        2
    )
from
    station;