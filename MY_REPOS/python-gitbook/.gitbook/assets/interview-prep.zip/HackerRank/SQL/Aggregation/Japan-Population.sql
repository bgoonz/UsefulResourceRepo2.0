select sum(population)
from city
where countrycode = 'JPN';