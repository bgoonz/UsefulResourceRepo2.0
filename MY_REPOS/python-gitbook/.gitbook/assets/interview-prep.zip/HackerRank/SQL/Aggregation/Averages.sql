select avg(population)
from city
where district = 'california';