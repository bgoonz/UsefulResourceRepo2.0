def reverseArray(a):
    return a[::-1]