# Enter your code here. Read input from STDIN. Print output to STDOUT
n = int(input())
c = set()
for i in range(n):
    c.add(input())
print(len(c))