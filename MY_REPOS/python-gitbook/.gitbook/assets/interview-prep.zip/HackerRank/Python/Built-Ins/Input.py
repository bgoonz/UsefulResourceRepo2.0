# Enter your code here. Read input from STDIN. Print output to STDOUT
x, k = map(int, input().split())
print("True" if eval(input())==k else "False")