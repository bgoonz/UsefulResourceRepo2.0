t = int(input())
while t:
    print(int(input()[::-1]))
    t -= 1