while True:
    n = int(input())
    if n == 42:
        break
    else:
        print(n)